btnSelectForm.onclick=function(){
  ChangeForm(customerSelect)
}

btnDeleteForm.onclick=function(){
  ChangeForm(customerDelete)
}

btnAddForm.onclick=function(){
  ChangeForm(customerAdd)
}

btnUpdateForm.onclick=function(){
  ChangeForm(customerUpdate)
}
